#include "Constants.h"

using namespace DriveConstants;

const frc::DifferentialDriveKinematics DriveConstants::kDriveKinematics(
    kTrackwidth);